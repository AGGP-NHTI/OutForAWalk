﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player2Sound : MonoBehaviour
{
    public AudioSource DeathAS;
    public AudioSource WitnessDeathAS;
    public AudioSource AttackAS;
    public AudioClip Death;
    public AudioClip WitnessedDeath;
    public AudioClip Attack;

    // PlayerControllers
    Player2Control p2c;

    private void Start()
    {
        p2c = gameObject.GetComponent<Player2Control>();
        DeathAS = DeathAS.GetComponent<AudioSource>();
        WitnessDeathAS = WitnessDeathAS.GetComponent<AudioSource>();
        AttackAS = AttackAS.GetComponent<AudioSource>();
    }

    private void Update()
    {
        if (p2c.isDead)
        {
            DeathPlay(Death);
        }

        if (Input.GetButtonDown(p2c.yell))
        {
            WitnessPlay(WitnessedDeath);
        }

        if (Input.GetButtonDown(p2c.attack))
        {
            AttackPlay(Attack);
        }
    }

    private void DeathPlay(AudioClip playClip)
    {
        DeathAS.clip = playClip;
        DeathAS.Play();
    }

    private void WitnessPlay(AudioClip playClip)
    {
        WitnessDeathAS.clip = playClip;
        WitnessDeathAS.Play();
    }

    private void AttackPlay(AudioClip playClip)
    {
        AttackAS.clip = playClip;
        AttackAS.Play();
    }

}
