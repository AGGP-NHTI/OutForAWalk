﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player1Sound : MonoBehaviour
{
    public AudioSource DeathAS;
    public AudioSource WitnessDeathAS;
    public AudioSource AttackAS;
    public AudioClip Death;
    public AudioClip WitnessedDeath;
    public AudioClip Attack;

    // PlayerControllers
    Player1Control p1c;

    private void Start()
    {
        p1c = gameObject.GetComponent<Player1Control>();
        DeathAS = DeathAS.GetComponent<AudioSource>();
        WitnessDeathAS = WitnessDeathAS.GetComponent<AudioSource>();
        AttackAS = AttackAS.GetComponent<AudioSource>();
    }

    private void Update()
    {
        if (p1c.isDead)
        {
            DeathPlay(Death);
        }

        if (Input.GetButtonDown(p1c.yell))
        {
            WitnessPlay(WitnessedDeath);
        }

        if (Input.GetButtonDown(p1c.attack))
        {
            AttackPlay(Attack);
        }
    }

    private void DeathPlay(AudioClip playClip)
    {
        DeathAS.clip = playClip;
        DeathAS.Play(); 
    }

    private void WitnessPlay(AudioClip playClip)
    {
        WitnessDeathAS.clip = playClip;
        WitnessDeathAS.Play();
    }

    private void AttackPlay(AudioClip playClip)
    {
        AttackAS.clip = playClip;
        AttackAS.Play();
    }
}
