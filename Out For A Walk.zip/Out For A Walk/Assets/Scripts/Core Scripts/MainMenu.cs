﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public GameObject menuPanel;

    string mainMenuScene = "MainMenu";
    string level1 = " "; // Update this with level's name, make more for more levels or make list for extra fun.


    private void Start()
    {
        DontDestroyOnLoad(gameObject);
        menuPanel.SetActive(true);
    }

    public void PlayGame()
    {
        SceneManager.LoadScene(level1);
        menuPanel.SetActive(false);
    }

    public void QuitGame()
    {
        Application.Quit();
    }

    void OnSceneLoaded(Scene scene, LoadSceneMode sceneMode)
    {
        if (mainMenuScene == scene.name)
        {
            Debug.Log("Main Menu");
            menuPanel.SetActive(true);
        }

        Debug.Log("Scene Loaded: " + scene.name);
        Debug.Log(sceneMode);
    }

}