﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BaseDamageType : MonoBehaviour
{
    public string verb = "damages";
    public bool Instakill = false;
    public bool CausedByWorld = false;
    // public bool IsPointDamage = false;
    // public bool ISRadialDamage = false;
}