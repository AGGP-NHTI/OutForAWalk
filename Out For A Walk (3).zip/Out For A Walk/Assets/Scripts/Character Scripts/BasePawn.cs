﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BasePawn : Pawn
{
    public virtual void runButton(bool value)
    {

    }

    public virtual void Horizontal(float value)
    {

    }

    public virtual void Vertical(float value)
    {

    }

    public virtual void Fire1(bool value)
    {

    }

    public virtual void Fire2(bool value)
    {

    }

    public virtual void Fire3(bool value)
    {

    }

    public virtual void Fire4(bool value)
    {

    }
}
