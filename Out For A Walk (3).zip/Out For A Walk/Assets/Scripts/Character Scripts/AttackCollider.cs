﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttackCollider : MonoBehaviour
{
    GameObject gameComponent;
    Game g;

    public float attackDamage;

    private void Start()
    {
        gameComponent = GameObject.Find("GameState");

        g = gameComponent.GetComponent<Game>();
    }

    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.name == g._player1Instance.name)
        {
            g._player1Instance.GetComponent<Player1Control>().TakeDamage(attackDamage);
        }

        if (col.gameObject.name == g._player2Instance.name)
        {
            g._player2Instance.GetComponent<Player2Control>().TakeDamage(attackDamage);
        }

        EnemyPawn ep = col.GetComponentInParent<EnemyPawn>();

        if(ep)
        {
            ep.TakeDamage(attackDamage);
        }

    }
}
