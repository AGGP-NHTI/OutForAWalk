﻿using UnityEngine;
using System.Collections;

public class CameraController : MonoBehaviour
{
    public GameObject player;
    public GameObject player2;
    private Vector3 offset;

    Player1Control p1c;
    Player2Control p2c;

    void Start()
    {
        offset = transform.position - player.transform.position;

        p1c = player.GetComponent<Player1Control>();
        p2c = player.GetComponent<Player2Control>();
    }

    void Update()
    {
        if (p1c.isDead && p1c.isOwner)
        {
            player = player2;
        }

        if (p2c.isDead && p2c.isOwner)
        {
            player2 = player;
        }
    }

    void LateUpdate()
    {
        transform.position = player.transform.position + offset;
    }
}